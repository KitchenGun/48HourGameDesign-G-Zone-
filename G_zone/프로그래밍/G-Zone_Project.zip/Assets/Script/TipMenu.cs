﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class TipMenu : MonoBehaviour
{

    //public GameObject tutorial;
    public GameObject click;
    public GameObject color;

    public GameObject click1;
    public GameObject color1;

    public GameObject clear;
    public GameObject clear1;

    public Sprite a;
    public Sprite b;
    public Sprite c;
    public Sprite d;
    public Sprite e;
    public Sprite f;
    public Sprite g;
    public Sprite h;
    public Sprite i;
    public Sprite j;
    public Sprite k;
    public int PG=0;

	// Use this for initialization
	void Start ()
    {
        PG = 0;
        click.SetActive(false);
        color.SetActive(false);
        click1.SetActive(false);
        color1.SetActive(false);
        clear.SetActive(false);
        clear1.SetActive(false);

    }
	
	// Update is called once per frame
	void Update ()
    {
        if(Input.GetKeyDown(KeyCode.Escape))
        {
            SceneManager.LoadScene("Stage");
        }
        if (PG == 0) 
        {
            GetComponent<Image>().sprite = a;
        }
        if (PG == 1)
        {
            GetComponent<Image>().sprite = b;
        }
        if (PG == 2)
        {
            GetComponent<Image>().sprite = c;
        }
        if (PG == 3)
        {
            GetComponent<Image>().sprite = d;
        }
        if (PG == 4)
        {
            GetComponent<Image>().sprite = e;
        }
        if (PG == 5)
        {
            GetComponent<Image>().sprite = f;
        }
        if (PG == 6)
        {
            GetComponent<Image>().sprite = g;
        }
        if (PG == 7)
        {
            GetComponent<Image>().sprite = h;
        }
        if (PG == 8)
        {
            GetComponent<Image>().sprite = i;
           
        }
        if (PG == 9)
        {
           
            GetComponent<Image>().sprite = j;
            click.SetActive(true);
            color.SetActive(true);
            click1.SetActive(true);
            color1.SetActive(true);
            clear.SetActive(true);
            clear1.SetActive(true);
        }
        if (PG == 10)
        {
            click1.SetActive(false);
            color1.SetActive(false);
            click.SetActive(false);
            color.SetActive(false);
            clear.SetActive(false);
            clear1.SetActive(false);
            GetComponent<Image>().sprite = k;
        }
    }

    public void addPage()
    {
        PG++;
        //마우스 애니메이션 위치
        if(PG>=11)
        {
            SceneManager.LoadScene("Stage");
        }
    }
}
