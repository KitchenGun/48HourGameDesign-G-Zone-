﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BGMSetting : MonoBehaviour
{
    public GameObject bgmfile;
    public static BGMSetting instance = null;
    // Use this for initialization
    private void Awake()
    {
        if (instance == null)
            instance = this;

        else if (instance != this)
            Destroy(bgmfile);
        
    }
    private void Start()
    {
        DontDestroyOnLoad(bgmfile);
    }

    // Update is called once per frame
    void Update ()
    {

	}
}
