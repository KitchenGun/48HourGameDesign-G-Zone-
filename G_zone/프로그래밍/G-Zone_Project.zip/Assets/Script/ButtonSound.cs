﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ButtonSound : MonoBehaviour
{
    public AudioClip click;
    AudioSource MyAudio;
    public static ButtonSound instance;

    private void Awake()
    {
        if (instance == null)
            instance = this;

        else if (instance != this)
            Destroy(this);
    }
    void Start ()
    {
        DontDestroyOnLoad(this);
        MyAudio = GetComponent<AudioSource>();
	}

    public void ClickSound()
    {
        MyAudio.Play();
    }
	
}
