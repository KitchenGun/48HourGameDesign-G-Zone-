﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Eventfont : MonoBehaviour
{
    public Animator Eventfontslot;


    int slot;

	void Start ()
    {
        slot = Random.Range(0, 3);
        Debug.Log(slot);

        if (slot == 0)
        {
            Eventfontslot.SetInteger("Result", 0);
        }
        if (slot == 1)
        {
            Eventfontslot.SetInteger("Result", 1);
        }
        if (slot == 2)
        {
            Eventfontslot.SetInteger("Result", 2);
        }
    }
	//
	//// Update is called once per frame
	//void FixedUpdate ()
    //{
    //    Debug.Log(slot);
    //
    //    if (slot == 0) 
    //    {
    //        Eventfontslot.SetInteger("Result", 0);
    //    }
    //    if (slot == 1)
    //    {
    //        Eventfontslot.SetInteger("Result", 1);
    //    }
    //    if (slot == 2)
    //    {
    //        Eventfontslot.SetInteger("Result", 2);
    //    }
    //}
}
