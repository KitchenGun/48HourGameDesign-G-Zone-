﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class ExitMenu : MonoBehaviour
{
    public GameObject Exitmenu;
	void Update ()
    {
		if(Input.GetKeyDown(KeyCode.Escape))
        {
            Exitmenu.SetActive(true);

            if (Input.GetKeyDown(KeyCode.Escape))
            {
                Exitmenu.SetActive(false);
            }
        }
	}
    public void Exit()
    {
        Application.Quit();
    }
    public void Noexit()
    {
        Exitmenu.SetActive(false);
    }
}
