﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class normalmode : MonoBehaviour
{

    public GameObject normalmenu;
    public GameObject tipmenu;
    public GameObject timeattackmenu;

    public GameObject normalbutton;
    public GameObject timeattackbutton;
    public GameObject tipbutton;
    public int a = 0;

    void Start ()
    {
        normalmenu.SetActive(false);
        timeattackmenu.SetActive(false);
        tipmenu.SetActive(false);
        a = 0;
    }

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            if(a==0)
            {
                SceneManager.LoadScene("Menu");
            }
            if (a == 1)
            {
                SceneManager.LoadScene("Stage");
            }
            if (a == 2)
            {
                SceneManager.LoadScene("Stage");
            }
            if (a == 3)
            {
                SceneManager.LoadScene("Stage");
            }
        }
        if(a>0)
        {
            DestroyImmediate(normalbutton);
            DestroyImmediate(timeattackbutton);
            //DestroyImmediate(tipbutton);
        }
    }

    public void onnormalmenu()
    {
        normalmenu.SetActive(true);
        a = 1;
    }
    public void ontimeattackmenu()
    {
        timeattackmenu.SetActive(true);
        a = 2;
    }
    public void ontipmenu()
    {
        tipmenu.SetActive(true);
        a = 3;
    }

}
