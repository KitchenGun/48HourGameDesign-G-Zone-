﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class LoadIn_Game : MonoBehaviour {

	public void Load_IngameScene_Easy()
    {
        CreateTile.difficult = 0;
        But.save_touchNumber = StageData.touchNumber = 18;
        But.save_time = StageData.time = 1;
        StageData.timeAttack = false;
        
        SceneManager.LoadScene("In-Game");
    }

    public void Load_IngameScene_Normal()
    {
        CreateTile.difficult = 1;
        But.save_touchNumber = StageData.touchNumber = 27;
        But.save_time = StageData.time = 1;
        StageData.timeAttack = false;
        SceneManager.LoadScene("In-Game");
    }

    public void Load_IngameScene_Hard()
    {
        CreateTile.difficult = 1;
        But.save_touchNumber = StageData.touchNumber = 20;
        But.save_time = StageData.time = 1;
        StageData.timeAttack = false;
        SceneManager.LoadScene("In-Game");
    }

    public void Load_IngameScene_TimeAt_Easy()
    {
        CreateTile.difficult = 0;
        But.save_time = StageData.time = 30;
        But.save_touchNumber = StageData.touchNumber = 1;
        StageData.timeAttack = true;
        StartCoroutine("Timer_");
        SceneManager.LoadScene("In-Game");
    }

    public void Load_IngameScene_TimeAt_Normal()
    {
        CreateTile.difficult = 1;
        But.save_time = StageData.time = 35;
        But.save_touchNumber = StageData.touchNumber = 1;
        StageData.timeAttack = true;
        StartCoroutine("Timer_");
        SceneManager.LoadScene("In-Game");
    }

    public void Load_IngameScene_TimeAt_Hard()
    {
        CreateTile.difficult = 1;
        But.save_time = StageData.time = 25;
        But.save_touchNumber = StageData.touchNumber = 1;
        StageData.timeAttack = true;
        StartCoroutine("Timer_");
        SceneManager.LoadScene("In-Game");
    }

    public IEnumerator Timer_()
    {
        StageData.time--;
        if (StageData.time == 0)
        {
            StopCoroutine("Timer_");
            SceneManager.LoadScene("Fail");
        }

        yield return new WaitForSeconds(1f);
    }

}
