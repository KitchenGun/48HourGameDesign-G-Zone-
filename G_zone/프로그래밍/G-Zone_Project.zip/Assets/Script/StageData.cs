﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StageData : MonoBehaviour
{

    static public int score = 0;
    static public int time;
    static public int touchNumber;
    static public bool timeAttack;

    private void Start()
    {
        DontDestroyOnLoad(this);
    }


}
