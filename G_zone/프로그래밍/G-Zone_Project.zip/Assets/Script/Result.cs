﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Result : MonoBehaviour
{


    public string scoret;
    public string timet;
    public string touchnumbert;

    public GameObject num4o;
    public GameObject num3o;
    public GameObject num2o;
    public GameObject num1o;

    int num4;
    int num3;
    int num2;
    int num1;



    int score;

    public Sprite one;
    public Sprite two;
    public Sprite three;
    public Sprite four;
    public Sprite five;
    public Sprite six;
    public Sprite seven;
    public Sprite eight;
    public Sprite nine;
    public Sprite zero;

    // Use this for initialization
    void Start ()
    {
        score= StageData.score;
        num4 = score / 1000;
        num3 = ((score - (1000 * num4)) / 100);
        num2 = (((score - (1000 * num4)) - (100 * num3)) / 10);
        num1 = (((score - (1000 * num4)) - (100 * num3)) - (10 * num2));
        Debug.Log(num4);
        Debug.Log(num3);
        Debug.Log(num2);
        Debug.Log(num1);
        if (num4 == 0) 
        {
            num4o.GetComponent<Image>().sprite = zero;
        }
        if (num4 == 1)
        {
            num4o.GetComponent<Image>().sprite = one;
        }
        if (num4 == 2)
        {
            num4o.GetComponent<Image>().sprite = two;
        }
        if (num4 == 3)
        {
            num4o.GetComponent<Image>().sprite = three;
        }
        if (num4 == 4)
        {
            num4o.GetComponent<Image>().sprite = four;
        }
        if (num4 == 5)
        {
            num4o.GetComponent<Image>().sprite = five;
        }
        if (num4 == 6)
        {
            num4o.GetComponent<Image>().sprite = six;
        }
        if (num4 == 7)
        {
            num4o.GetComponent<Image>().sprite = seven;
        }
        if (num4 == 8)
        {
            num4o.GetComponent<Image>().sprite = eight;
        }
        if (num4 == 9)
        {
            num4o.GetComponent<Image>().sprite = nine;
        }
        if (num3 == 0)
        {
            num3o.GetComponent<Image>().sprite = zero;
        }
        if (num3== 1)
        {
            num3o.GetComponent<Image>().sprite = one;
        }
        if (num3 == 2)
        {
            num3o.GetComponent<Image>().sprite = two;
        }
        if (num3 == 3)
        {
            num3o.GetComponent<Image>().sprite = three;
        }
        if (num3 == 4)
        {
            num3o.GetComponent<Image>().sprite = four;
        }
        if (num3 == 5)
        {
            num3o.GetComponent<Image>().sprite = five;
        }
        if (num3 == 6)
        {
            num3o.GetComponent<Image>().sprite = six;
        }
        if (num3 == 7)
        {
            num3o.GetComponent<Image>().sprite = seven;
        }
        if (num3 == 8)
        {
            num3o.GetComponent<Image>().sprite = eight;
        }
        if (num3 == 9)
        {
            num3o.GetComponent<Image>().sprite = nine;
        }
        if (num2 == 0)
        {
            num2o.GetComponent<Image>().sprite = zero;
        }
        if (num2 == 1)
        {
            num2o.GetComponent<Image>().sprite = one;
        }
        if (num2 == 2)
        {
            num2o.GetComponent<Image>().sprite = two;
        }
        if (num2 == 3)
        {
            num2o.GetComponent<Image>().sprite = three;
        }
        if (num2 == 4)
        {
            num2o.GetComponent<Image>().sprite = four;
        }
        if (num2 == 5)
        {
            num2o.GetComponent<Image>().sprite = five;
        }
        if (num2 == 6)
        {
            num2o.GetComponent<Image>().sprite = six;
        }
        if (num2 == 7)
        {
            num2o.GetComponent<Image>().sprite = seven;
        }
        if (num2 == 8)
        {
            num2o.GetComponent<Image>().sprite = eight;
        }
        if (num2 == 9)
        {
            num2o.GetComponent<Image>().sprite = nine;
        }
        if (num1 == 0)
        {
            num1o.GetComponent<Image>().sprite = zero;
        }
        if (num1 == 1)
        {
            num1o.GetComponent<Image>().sprite = one;
        }
        if (num1 == 2)
        {
            num1o.GetComponent<Image>().sprite = two;
        }
        if (num1 == 3)
        {
            num1o.GetComponent<Image>().sprite = three;
        }
        if (num1 == 4)
        {
            num1o.GetComponent<Image>().sprite = four;
        }
        if (num1 == 5)
        {
            num1o.GetComponent<Image>().sprite = five;
        }
        if (num1 == 6)
        {
            num1o.GetComponent<Image>().sprite = six;
        }
        if (num1 == 7)
        {
            num1o.GetComponent<Image>().sprite = seven;
        }
        if (num1 == 8)
        {
            num1o.GetComponent<Image>().sprite = eight;
        }
        if (num1 == 9)
        {
            num1o.GetComponent<Image>().sprite = nine;
        }
    }
	
}
