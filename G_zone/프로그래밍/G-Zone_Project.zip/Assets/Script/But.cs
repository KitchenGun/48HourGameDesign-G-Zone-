﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class But : MonoBehaviour
{
    static public int save_time;
    static public int save_touchNumber;

    public void Restart()
    {
        StageData.time = save_time;
        StageData.touchNumber = save_touchNumber;
        SceneManager.LoadScene("In-Game");
    }

    public void Resume()
    {
        SceneManager.LoadScene("Stage");
    }

}
