﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class TouchTile : MonoBehaviour {

    public int Colornum;
    static public int sta_colornum;

    private SpriteRenderer spr;

    void Awake()
    {
        spr = GetComponent<SpriteRenderer>();
    }

    void OnMouseDown()
    {
        Vector2 pos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        RaycastHit2D hit = Physics2D.Raycast(pos, Vector2.zero, 0f);

        if (StageData.touchNumber != 0 && StageData.time != 0)
        {
            if (hit.collider != null) // 타일이 선택 되면 
            {
                if(StageData.timeAttack == false)
                    StageData.touchNumber--;
                if (Colornum < 6)
                    Colornum++;

                sta_colornum = Colornum;
                spr.color = StaticData.ColorTable[Colornum];
                GameObject.Find("GameManager").GetComponent<CreateTile>().RefreshColor();
                IsWin.Init();

                if (CreateTile.difficult == 0)
                {
                    for (int i = 0; i < 7; i++)
                    {
                        Debug.Log("i : " + i);
                        IsWin.IsWIN(1, 0, 1, i); // 타일 터치 시 마다 승리 판정 함수 호출 

                    }
                }
                else if (CreateTile.difficult == 1)
                {
                    for (int i = 0; i < 7; i++)
                    {
                        Debug.Log("i : " + i);
                        IsWin.IsWIN(2, 0, 1, i); // 타일 터치 시 마다 승리 판정 함수 호출*/
                    }
                }
            }
        }
        else
        {
            SceneManager.LoadScene("Fail");
        }
    }
}
