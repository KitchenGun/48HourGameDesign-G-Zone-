﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SelectMapImage : MonoBehaviour
{
    static public SpriteRenderer sr;

    // Use this for initialization
    void Start()
    {
        sr = gameObject.GetComponent<SpriteRenderer>();
        if (CreateTile.difficult == 0 && StageData.timeAttack == false)
            sr.sprite = (Sprite)Resources.Load("easy_BG", typeof(Sprite));
        else if (CreateTile.difficult == 1 && StageData.timeAttack == false)
            sr.sprite = (Sprite)Resources.Load("normal,hard_BG", typeof(Sprite));
        else if (CreateTile.difficult == 0 && StageData.timeAttack == true)
            sr.sprite = (Sprite)Resources.Load("TimeAttack2", typeof(Sprite));
        else if (CreateTile.difficult == 1 && StageData.timeAttack == true)
            sr.sprite = (Sprite)Resources.Load("TimeAttack1", typeof(Sprite));
    }
}
