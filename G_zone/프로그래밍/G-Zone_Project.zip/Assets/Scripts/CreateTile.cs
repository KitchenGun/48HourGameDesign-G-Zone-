﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CreateTile : MonoBehaviour {

    static public int clickCount;
    public GameObject prepabs; // 타일 프리팹 
    public GameObject[,] Tiles; // 타일 오브젝트 배열 
    static public int[,] Tiles_color; // 타일 컬러 
    private Vector3 Startpos;         // 시작 지점 
    static public int difficult;      // 난이도 
    private float xpos;               
    private float ypos;
    public int m, n;
    static public int M;
    static public int N;

    // easy   사이즈 15개 가로 3개 세로 5개 m : 가로 n : 세로
    // normal 사이즈 40개 가로 5 세로 8
    // hard   사이즈 40개 가로 5 세로 8

    void Awake () {
        Vector3 tempPos = new Vector3(-2.4f, 4f, 0f);
        Startpos = tempPos;

        if (difficult == 0)
        {
            m = 3; n = 5;
        }
        else
        {
            m = 5; n = 8;
        }

        M = m;
        N = n;

        Tiles = new GameObject[n,m];
        Tiles_color = new int[n, m];

        for(int i = 0; i < n; i++)
        {
            tempPos.x = Startpos.x;

            for(int j = 0; j < m; j++)
            {
                Tiles[i,j] = Instantiate(prepabs, tempPos, prepabs.transform.rotation) as GameObject;
                Tiles[i,j].transform.localScale = StaticData.SquareSize[difficult];
                Tiles[i, j].gameObject.GetComponent<TouchTile>().Colornum = Random.Range(0, 6);
                Tiles[i,j].gameObject.GetComponent<SpriteRenderer>().color = StaticData.ColorTable[Tiles[i, j].gameObject.GetComponent<TouchTile>().Colornum];
                tempPos.x += StaticData.SquareSize[difficult].x;
                //Debug.Log("" + j);
            }
            tempPos.y -= StaticData.SquareSize[difficult].y;
        }

        if(difficult == 0)
        {
            Tiles[0, 1].GetComponent<SpriteRenderer>().color = new Vector4(1, 1, 1, 1);
            Tiles[0, 1].tag = "StartPoint";
            Tiles[4, 2].GetComponent<SpriteRenderer>().color = new Vector4(1, 1, 1, 1);
            Tiles[4, 2].tag = "EndPoint";
            Destroy(Tiles[0, 1].GetComponent<BoxCollider2D>());
            Destroy(Tiles[4, 2].GetComponent<BoxCollider2D>());
        }
        else
        {
            Tiles[0, 2].GetComponent<SpriteRenderer>().color = new Vector4(1, 1, 1, 1);
            Tiles[0, 2].tag = "StartPoint";
            Destroy(Tiles[0, 2].GetComponent<BoxCollider2D>());

            Tiles[6, 4].GetComponent<SpriteRenderer>().color = new Vector4(1, 1, 1, 1);
            Tiles[6, 4].tag = "EndPoint";
            Destroy(Tiles[6, 4].GetComponent<BoxCollider2D>());
        }


        Debug.Log("Complete");
    }

    public void RefreshColor()
    {
        for (int i = 0; i < N; i++)
            for (int j = 0; j < M; j++)
                Tiles_color[i, j] = Tiles[i, j].gameObject.GetComponent<TouchTile>().Colornum;
    }
}
