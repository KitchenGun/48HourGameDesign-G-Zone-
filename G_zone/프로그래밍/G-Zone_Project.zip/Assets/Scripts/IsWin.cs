﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class IsWin : MonoBehaviour {

    public struct TileInfo
    {
        public bool ispass;
        public int color_num;
        public bool isfine;
    }

    static private int min;
    static public TileInfo[,] strucTile;

    void Awake()
    {
        strucTile = new TileInfo[CreateTile.N, CreateTile.M];
    }

    static public void Init()
    {
        Debug.Log("Asdsad");

        if (CreateTile.difficult == 0)
        {
            strucTile[4, 2].isfine = true;
            strucTile[4, 2].ispass = false;
        }
        else if (CreateTile.difficult == 1)
        {
            strucTile[6, 4].isfine = true;
            strucTile[4, 2].ispass = false;
        }

        // 타일 상태 복사 
        for (int i = 0; i < CreateTile.N; i++)
        {
            for (int j = 0; j < CreateTile.M; j++)
            {
                Debug.Log("bool : " + strucTile[i, j].ispass);
                strucTile[i, j].ispass = false;
                strucTile[i, j].color_num = CreateTile.Tiles_color[i, j];
                strucTile[i, j].isfine = false;
            }
        }
    }

    static public void IsWIN(int x, int y, int l, int color)
    {
        Debug.Log("Start DFS " + l);
        // 타일 정보 복사 후 길 탐색 시작. 

        Check(x, y, l);

        strucTile[y, x].ispass = true; //true = 0 false = 1

        if ( (y > 0 && strucTile[y - 1, x].isfine) || (y > 0 && !strucTile[y - 1, x].ispass && color == strucTile[y - 1, x].color_num))
        {
            Debug.Log("Searching [UP] [" + x + "," + (y-1) + "] " + strucTile[y,x].color_num + " " + strucTile[y - 1, x].color_num);
            IsWIN(x, y - 1, l + 1, color);
        }
        if ( (y < CreateTile.N - 1 && strucTile[y + 1, x].isfine) || (y < CreateTile.N - 1 && !strucTile[y + 1, x].ispass && color == strucTile[y + 1, x].color_num))
        {
            Debug.Log("Searching [DOWN] [" + x + "," + (y+1) + "] " + strucTile[y, x].color_num + " " + strucTile[y + 1, x].color_num);
            IsWIN(x, y + 1, l + 1, color);
        }
        if ((x > 0 && strucTile[y, x - 1].isfine) || (x > 0 && !strucTile[y, x - 1].ispass && color == strucTile[y, x - 1].color_num))
        {
            Debug.Log("Searching [LEFT] [" + (x-1) + "," + y + "] " + strucTile[y, x].color_num + " " + strucTile[y, x - 1].color_num);
            IsWIN(x - 1, y, l + 1, color);
        }
        if ((x < CreateTile.M - 1 && strucTile[y, x + 1].isfine) || (x < CreateTile.M - 1 && !strucTile[y, x + 1].ispass && color == strucTile[y, x + 1].color_num))
        {
            Debug.Log("Searching [RIGHT] [" + (x+1) + "," + y + "]" + strucTile[y, x].color_num + " " + strucTile[y, x + 1].color_num);
            IsWIN(x + 1, y, l + 1, color);
        }

        return;
    }

    static void Check(int x, int y, int l)
    {
        if (CreateTile.difficult == 0 && ((x == 2 && y == 3) || (x == 1 && y == 3)))
        {
            if (min > l) min = l;
            Debug.Log("Clear!!!!!!!!!!!!!!!!!!!!!!! - Distance" + l);
            SceneManager.LoadScene("Result");
            return;
        }
        else if (CreateTile.difficult == 1 && ((x == 4 && y == 5) || (x == 3 && y == 6) || (x == 4 && y == 7)))
        {
            if (min > l) min = l;
            Debug.Log("Clear!!!!!!!!!!!!!!!!!!!!!!! - Distance" + l);
            SceneManager.LoadScene("Result");
            return;
        }
    }

}
