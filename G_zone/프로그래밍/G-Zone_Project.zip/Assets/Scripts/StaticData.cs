﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StaticData : MonoBehaviour {

    public static Vector4[] ColorTable = new Vector4[8]   // 0 ~ 6 -> 빨강 ~ 보라
    {
        new Vector4(1, 0, 0, 1), //R  0
        new Vector4(1f, 0.5f, 0, 1), // O  1
        new Vector4(1, 0.92f, 0.016f,1), // Y  2
        new Vector4(0.2f, 0.8f, 0.4f,1), // G  3
        new Vector4(0, 0, 1, 1), // B  4
        new Vector4(0.1f, 0.1f, 0.5f, 1), // 남색  5
        new Vector4(0.8f, 0.1f, 0.6f, 1), // P  6
        new Vector4(1, 1, 1, 1)
    };

    public static Vector3[] SquareSize = new Vector3[3]
    {
        new Vector3(1.6f, 1.6f, 0f),        // easy   사이즈 15개 가로 3개 세로 5개 
        new Vector3(0.96f, 1f, 0f),         // normal 사이즈 40개 가로 5 세로 8
        new Vector3(0.96f, 1f, 0f)          // hard   사이즈 40개 가로 5 세로 8
    };
}
